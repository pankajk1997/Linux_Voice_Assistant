#!/bin/bash
# Copyright 2013 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

set -e

if [ "$(uname -s)" == "Linux" ]; then
  if [ "$(whoami)" == "root" ]; then
    TARGET_DIR="/etc/opt/chrome/native-messaging-hosts"
    TARGET_DIR1="/etc/chromium/native-messaging-hosts" 
  else
    TARGET_DIR="$HOME/.config/google-chrome/NativeMessagingHosts"
    TARGET_DIR1="$HOME/.config/chromium/NativeMessagingHosts"
  fi
fi

HOST_NAME=ru.speechpad.host
rm "$TARGET_DIR/ru.speechpad.host.json"
rm "$TARGET_DIR1/ru.speechpad.host.json"
echo "Native messaging host $HOST_NAME has been uninstalled."
