﻿Модуль интеграции голосового блокнота с Linux (32 bit)
 Copyright © Design-Sites.ru 2016



Инсталяция:
 Разархивировать файлы в папку на диске

 Запустить файл install_host.sh



Деинсталляция:

 Запустить файл uninstall_host.sh

 Удалить папку с диска


The Speechpad Linux integration module (32 bit)

   Copyright © Design-Sites.ru 2016
 
  

To install:
 Unzip the files to some directory on the disk

 Run install_host.sh file



To remove:

 uninstall_host.sh
 Remove the folder from disk
