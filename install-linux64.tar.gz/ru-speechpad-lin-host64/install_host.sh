#!/bin/bash


set -e

DIR="$( cd "$( dirname "$0" )" && pwd )"
if [ "$(uname -s)" == "Linux" ]; then

  if [ "$(whoami)" == "root" ]; then
    TARGET_DIR="/etc/opt/chrome/native-messaging-hosts"
    TARGET_DIR1="/etc/chromium/native-messaging-hosts"   
  else
    TARGET_DIR="$HOME/.config/google-chrome/NativeMessagingHosts"
    TARGET_DIR1="$HOME/.config/chromium/NativeMessagingHosts"
  fi
fi

HOST_NAME=ru.speechpad.host

# Create directory to store native messaging host.
mkdir -p "$TARGET_DIR"
mkdir -p "$TARGET_DIR1"

# Copy native messaging host manifest.
cp "$DIR/$HOST_NAME.json" "$TARGET_DIR"
cp "$DIR/$HOST_NAME.json" "$TARGET_DIR1"

# Update host path in the manifest.
HOST_PATH=$DIR/ru-speechpad-host.out
ESCAPED_HOST_PATH=${HOST_PATH////\\/}
sed -i -e "s/HOST_PATH/$ESCAPED_HOST_PATH/" "$TARGET_DIR/$HOST_NAME.json"
sed -i -e "s/HOST_PATH/$ESCAPED_HOST_PATH/" "$TARGET_DIR1/$HOST_NAME.json"

# Set permissions for the manifest so that all users can read it.
chmod o+r "$TARGET_DIR/$HOST_NAME.json"
chmod o+r "$TARGET_DIR1/$HOST_NAME.json"
chmod u+x,g+x,o+x $HOST_PATH

echo "Native messaging host $HOST_NAME has been installed."
